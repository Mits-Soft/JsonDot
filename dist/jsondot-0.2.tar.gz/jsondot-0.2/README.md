# JsonDot
Python library for loading JSON files and use them with dot notation then dump to the file again
